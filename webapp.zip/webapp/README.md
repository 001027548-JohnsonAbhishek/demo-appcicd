# webapp

This is a spring boot app and the following are the details about the dev environment and running the app :

## Steps :
- Install Java
- Install spring boot framework and clone the above repo

## Running the app:
- You need to press the run button on the top to start the server.
- Then we can test the api functionality using POSTMAN.
